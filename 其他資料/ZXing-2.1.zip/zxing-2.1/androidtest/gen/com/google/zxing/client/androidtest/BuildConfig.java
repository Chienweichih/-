/** Automatically generated file. DO NOT MODIFY */
package com.google.zxing.client.androidtest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}